
Diario di lavoro
##### Nikola Momcilovic, Jacopo Greppi
### Canobbio, [25.11.2016]
### Inizio ufficiale dei progetti

## Analisi

## Lavori svolti
Lavoro svolto da Nikola Momcilovic e Jacopo Greppi

Nikola:
Ha fatto una ricerca e prove su come far interazionare MySQL con PHP.

Jacopo:
Gantt, Ricerca di un possibile webhosting di media fascia in svizzera , Tabella

##  Problemi riscontrati e soluzioni adottate
Touchpad computer di nikola flascava.

##  Punto della situazione rispetto alla pianificazione
Analisi dei singoli requisiti.


## Programma di massima per la prossima giornata di lavoro
Concludere la parte della progettazione, digitalizzandola e avere l'ok del docente
