
Diario di lavoro
##### Nikola Momcilovic, Jacopo Greppi
### Canobbio, [02.12.2016]
### Inizio ufficiale dei progetti

## Analisi

## Lavori svolti
Lavoro svolto da Nikola Momcilovic e Jacopo Greppi

Nikola:
Dalle 10:05 fino alle 11:00 si è occupato della parte che concerne l'interazione tra php e mysql.
Dalle 11:00 fino alle 15:00 si è occupato della realizzazione, tramite un software, della progettazione della parte grafica del progetto.
Dalle 15:00 fino alle 15:45 si è occupato della realizzazione, tramite un software, dello schema er del progetto.

Jacopo:
Durante la mattinata (dalle 10:05 fino alle 12:20) ha realizzato lo use case del progetto. Una volta svolto è stato fatto vedere al docente responsabile per verificare se fosse idoneo. Essendo stato realizzato nel modo corretto, è stato inserito nella documentazione sotto il capitolo "Use Case"
Durante il pomerggio (dalle 13:15 fino alle 14:00) ha realizzato la tabella dei costi delle risorse del progetto.
Dalle 14:00 fino alle 15:40 si è occupato dello studio di un framework (bootstrap) che deve essere usato per la realizzazione della parte web del progetto  
Gli ultimi 5 minuti sono stati dedicati alla realizzazione del diario su Github.

##  Problemi riscontrati e soluzioni adottate
Oggi non è stato riscontrato nessun problema

##  Punto della situazione rispetto alla pianificazione
Rispetto al gantt siamo messi bene. Ciò che era da svolgere entro la giornata odierna è stato fatto. Eccezione fatta per il completamento dello schema er e della progettazione della parte grafica.


## Programma di massima per la prossima giornata di lavoro
Entro la fine della prossima lezione ci prefissiamo di terminare lo schema er e la progettazione della parte grafica del progetto.
