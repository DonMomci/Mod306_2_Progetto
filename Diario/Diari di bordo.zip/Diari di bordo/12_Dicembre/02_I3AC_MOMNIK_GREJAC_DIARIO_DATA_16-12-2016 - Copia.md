
Diario di lavoro
##### Nikola Momcilovic, Jacopo Greppi
### Canobbio, [16.12.2016]
### Inizio ufficiale dei progetti

## Analisi

## Lavori svolti
Lavoro svolto da Nikola Momcilovic e Jacopo Greppi

Nikola:
Nell'arco della giornata si è occupato di terminare tutte le interfacce grafiche preparandole per l'interazione con il database per php.
Sucessivamente ha effettuato dei test locali per esercitarsi con l'interazione PHP/MySQL.

Jacopo:
Inizialmente ha dato una mano a Nikola per le implementazioni delle interfacce e sucessivamente si è occupato di documentare il progetto.

##  Problemi riscontrati e soluzioni adottate
Nella lezione odierna si sono riscontrati unicamente problemi poco rilevanti con l'utilizzo di bootstrap, che si sono risolti in poco tempo.

##  Punto della situazione rispetto alla pianificazione
Tutto in regola, per il momento non sono stati riscontrati spostamenti nella pianificazione.

## Programma di massima per la prossima giornata di lavoro
Popolare con pochi dati il database, implentare il funzionamento corretto del login e preparare le query in php.
