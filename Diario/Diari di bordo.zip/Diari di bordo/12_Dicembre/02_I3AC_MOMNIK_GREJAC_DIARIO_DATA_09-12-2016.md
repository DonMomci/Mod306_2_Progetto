
Diario di lavoro
##### Nikola Momcilovic, Jacopo Greppi
### Canobbio, [09.12.2016]
### Inizio ufficiale dei progetti

## Analisi

## Lavori svolti
Lavoro svolto da Nikola Momcilovic e Jacopo Greppi

Nikola:
Durante le tre ore del mattino si è occupato di creare la pagina di login tramite l'uso dell'HTML e di bootstrap.
Nel pomeriggio ha iniziato a preparare le pagine dell'utente amministratore e dell'ospite una volta fatto il login. Anche queste 2 pagine web implicano l'utilizzo di HTML e bootstrap

Jacopo:
Al mattino ha ultimato lo schema ER già iniziato nelle lezioni precedenti. Dopo un accertamento è stato ricreato tramite un programma e successivamente lo ha fatto vedere al docente. Dopo 3 piccole modifiche ha potuto creare il database in Heidisql.
Durante gli ultimi minuti della lezione si è occupato della realizzazione del diario della lezione odierna.

##  Problemi riscontrati e soluzioni adottate
Jacopo ha trovato delle difficoltà nella realizzazione del database poiché l'interfaccia grafica dà dei problemi nel gestire le foreign key. Questo inconveniente è stato risolto inserendo le chiavi esterne tramite linea di comando.

##  Punto della situazione rispetto alla pianificazione

Rispetto alla pianificazione siamo a buon punto poiché oggi abbiamo terminato la parte di progettazione di base. La chiamo "di base" poiché durante la parte d'implementazione riscontreremo sicuramente dei problemi che ci faranno rivedere la progettazione.

## Programma di massima per la prossima giornata di lavoro

La settimana seguente continueremo con l'implementazione che è già stata cominciata oggi.

